package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class CadastroActivity extends AppCompatActivity {
    private TextInputLayout txtCadastroInput;
    private Button btnCadastrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.cadastro);
        txtCadastroInput = findViewById(R.id.txtCadastroInput);
        btnCadastrar = findViewById(R.id.btnCadastro);
        btnCadastrar.setOnClickListener(view -> {
            String nome = (txtCadastroInput.getEditText() != null) ? txtCadastroInput.getEditText().getText().toString() : "";
            if (nome.trim().isEmpty()){
                txtCadastroInput.setError("Preencha o nome");
                return;
            } else {
                txtCadastroInput.setError(null);
            }
            Intent intent = new Intent(this, ConfirmaCadastroActivity.class);
            intent.putExtra("nome", nome);
            startActivity(intent);
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}