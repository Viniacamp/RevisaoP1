package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class FormularioPedidoActivity extends AppCompatActivity {
    private TextInputLayout txtNomeInput;
    private Button btnPedir;
    private RadioGroup rgLanches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.formulariopedido);
        inicializar();
        btnPedir.setOnClickListener(view -> {
            String nome = (txtNomeInput.getEditText() != null) ? txtNomeInput.getEditText().getText().toString() : "";
            if (nome.trim().isEmpty()){
                txtNomeInput.setError("Insira seu Nome");
                return;
            } else {
                txtNomeInput.setError(null);
            }
            String lanche = pegarNomeLanche();
            if (lanche == null){
                Toast.makeText(this, "Escolha um lanche", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, ResultadoPedidoActivity.class);
            intent.putExtra("nome", nome);
            intent.putExtra("lanche", lanche);
            startActivity(intent);
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void inicializar(){
        txtNomeInput = findViewById(R.id.txtNomeInput);
        btnPedir = findViewById(R.id.btnPedir);
        rgLanches = findViewById(R.id.rgLanches);
    }

    private String pegarNomeLanche(){
        int id = rgLanches.getCheckedRadioButtonId();
        if (id == -1){
            return null;
        }
        RadioButton selecionado = findViewById(id);
        String lanche = selecionado.getText().toString();

        return lanche;
    }
}