package br.gov.sp.cps.menuaplicativos;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class SalarioFuncionarioActivity extends AppCompatActivity {
    private TextInputLayout txtInput;
    private RadioGroup rgPorcentagens;

    private Button btnCalcular, btnVoltar;

    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.salariofuncionario);
        inicializarComponentes();
        btnCalcular.setOnClickListener(view -> {
            String texto = (txtInput.getEditText() != null) ? txtInput.getEditText().getText().toString()  : "";
            Log.i("teste", texto);
            if (texto.trim().isEmpty()){
                txtInput.setError("Digite um valor");
                return;
            } else {
                txtInput.setError(null);
            }

            if (rgPorcentagens.getCheckedRadioButtonId() == -1){
                Toast.makeText(this, "Selecione uma porcentagem", Toast.LENGTH_SHORT).show();
                return;
            }

            double salario = Double.parseDouble(texto);
            salario *= aumentar();
            String salarioFormatado = String.format("%.2f", salario).replace(".", ",");
            txtResultado.setText("Novo Salário: R$ " + salarioFormatado);
        });

        btnVoltar.setOnClickListener(view -> {
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private void inicializarComponentes(){
        txtInput = findViewById(R.id.textInputLayoutSalario);
        rgPorcentagens = findViewById(R.id.rgPorcentagem);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);
        btnVoltar = findViewById(R.id.btnVoltar);

    }

    private double aumentar(){
        RadioButton selecionado = findViewById(rgPorcentagens.getCheckedRadioButtonId());
        String texto = selecionado.getText().toString();
        switch (texto){
            case "40%":
                return 1.40;
            case "45%":
                return 1.45;
            case "50%":
                return 1.50;
            default:
                return 1.0;
        }
    }
}