package br.gov.sp.cps.menuaplicativos;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SistemaComprasActivity extends AppCompatActivity {
    private CheckBox ckArroz, ckFeijao, ckCarne, ckLeite, ckCoca;
    private TextView txtResultado;
    private Button btnCompra, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.sistemacompras);
        inicializarComponentes();
        btnCompra.setOnClickListener(view -> {
            double total = calcular();
            String totalFormatado = String.format("%.2f", total).replace(".", ",");
            txtResultado.setText("Total: R$ " + totalFormatado);
        });

        btnVoltar.setOnClickListener(view -> {
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void inicializarComponentes(){
        ckArroz = findViewById(R.id.ckArroz);
        ckCarne = findViewById(R.id.ckCarne);
        ckFeijao = findViewById(R.id.ckFeijao);
        ckLeite = findViewById(R.id.ckLeite);
        ckCoca = findViewById(R.id.ckCoca);
        txtResultado = findViewById(R.id.txtResultado);
        btnCompra = findViewById(R.id.btnCompra);
        btnVoltar = findViewById(R.id.btnVoltar);
    }

    private double calcular(){
        double total = 0;
        if (ckArroz.isChecked()){
            total += 2.69;
        }
        if (ckFeijao.isChecked()){
            total += 2.30;
        }
        if (ckCarne.isChecked()){
            total += 10.00;
        }
        if (ckLeite.isChecked()){
            total += 5.00;
        }
        if (ckCoca.isChecked()){
            total += 2.00;
        }
        return total;
    }
}