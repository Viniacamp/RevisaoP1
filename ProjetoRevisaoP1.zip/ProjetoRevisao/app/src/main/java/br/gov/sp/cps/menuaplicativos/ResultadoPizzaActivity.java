package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoPizzaActivity extends AppCompatActivity {
    private TextView txtResultado;
    private Button btnOutroPedido, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.resultadopizza);
        Intent intentResultado = getIntent();
        txtResultado = findViewById(R.id.txtResultado);
        btnOutroPedido = findViewById(R.id.btnOutroPedido);
        btnVoltar = findViewById(R.id.btnVoltar);
        String tamanho = intentResultado.getStringExtra("tamanho");
        String pagamento = intentResultado.getStringExtra("pagamento");
        String sabores = intentResultado.getStringExtra("sabores");
        String preco = intentResultado.getStringExtra("preco");
        String texto = "Sabores: " + sabores + "\n" + "Tamanho: " + tamanho + "\n" + "Preço: " + preco + "\n" + "Pagamento: " + pagamento;
        txtResultado.setText(texto);
        btnOutroPedido.setOnClickListener(view -> {
            Intent intentPizzaria = new Intent(this, PizzariaActivity.class);
            startActivity(intentPizzaria);
            finish();
        });
        btnVoltar.setOnClickListener(view -> {
            Intent intentMenu = new Intent(this, MainActivity.class);
            intentMenu.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentMenu);
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}