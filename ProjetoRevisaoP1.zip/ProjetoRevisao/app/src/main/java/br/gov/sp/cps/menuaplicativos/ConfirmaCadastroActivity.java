package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ConfirmaCadastroActivity extends AppCompatActivity {
    private TextView txtResultado;
    private Button btnVoltarMenuTemdeTudo, btnVoltarMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.confirmacadastro);
        Intent intentCadastro = getIntent();
        txtResultado = findViewById(R.id.txtResultado);
        btnVoltarMenu = findViewById(R.id.btnVoltar);
        btnVoltarMenuTemdeTudo = findViewById(R.id.btnVoltarMenuTemDeTudo);
        txtResultado.setText("Bem-vindo " + intentCadastro.getStringExtra("nome") + ", seu cadastro foi realizado com sucesso!");
        btnVoltarMenu.setOnClickListener(view -> {
            Intent intentMenu = new Intent(this, MainActivity.class);
            intentMenu.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentMenu);
            finish();
        });
        btnVoltarMenuTemdeTudo.setOnClickListener(view -> {
            Intent intentMenuTemdeTudo = new Intent(this, TemdetudoActivity.class);
            startActivity(intentMenuTemdeTudo);
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}