package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button btnPizzaria, btnLancheFacil, btnTemdeTudo, btnSistemaCompras, btnSalarioFuncionario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        inicializar();
        btnPizzaria.setOnClickListener(view -> {
            Intent intentPizzaria = new Intent(this, PizzariaActivity.class);
            startActivity(intentPizzaria);
        });
        btnLancheFacil.setOnClickListener(view -> {
            Intent intentLancheFacil = new Intent(this, LanchefacilActivity.class);
            startActivity(intentLancheFacil);
        });
        btnTemdeTudo.setOnClickListener(view -> {
            Intent intentTemdeTudo = new Intent(this, TemdetudoActivity.class);
            startActivity(intentTemdeTudo);
        });
        btnSistemaCompras.setOnClickListener(view -> {
            Intent intentSistemaCompras = new Intent(this, SistemaComprasActivity.class);
            startActivity(intentSistemaCompras);
        });
        btnSalarioFuncionario.setOnClickListener(view -> {
            Intent intentSalarioFuncionario = new Intent(this, SalarioFuncionarioActivity.class);
            startActivity(intentSalarioFuncionario);
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void inicializar(){
        btnPizzaria = findViewById(R.id.btnPizzaria);
        btnLancheFacil = findViewById(R.id.btnLancheFacil);
        btnTemdeTudo = findViewById(R.id.btnTemDeTudo);
        btnSistemaCompras = findViewById(R.id.btnSistemaCompras);
        btnSalarioFuncionario = findViewById(R.id.btnSalarioFuncionario);


    }
}