package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoPedidoActivity extends AppCompatActivity {
    private Button btnVoltar, btnVoltarMenuLancheFacil;

    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.resultadopedido);
        btnVoltar = findViewById(R.id.btnVoltar);
        txtResultado = findViewById(R.id.txtResultado);
        btnVoltarMenuLancheFacil = findViewById(R.id.btnVoltarLancheFacil);
        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String lanche = intent.getStringExtra("lanche");
        txtResultado.setText("Nome: " + nome + "\nLanche: " + lanche);
        btnVoltar.setOnClickListener(view -> {
            Intent intentVoltar = new Intent(this, MainActivity.class);
            intentVoltar.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intentVoltar);
            finish();
        });
        btnVoltarMenuLancheFacil.setOnClickListener(view -> {
            Intent intentLanche = new Intent(this, LanchefacilActivity.class);
            startActivity(intentLanche);
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}