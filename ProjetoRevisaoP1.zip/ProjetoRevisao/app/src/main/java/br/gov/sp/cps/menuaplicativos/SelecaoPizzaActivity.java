package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SelecaoPizzaActivity extends AppCompatActivity {
    private RadioGroup rgPizzaTamanho, rgPagamento;
    private RadioButton rbBroto, rbMedia, rbGrande, rbExtraGrande;
    private Button btnConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.selecaopizza);
        inicializarComponentes();
        Intent intentSabores = getIntent();
        btnConfirmar.setOnClickListener(view -> {
            if (rgPizzaTamanho.getCheckedRadioButtonId() == -1 || rgPagamento.getCheckedRadioButtonId() == -1){
                Toast.makeText(this, "Selecione todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }
            String[] tamanhoPreco = pegarTamanhoEscolhido();
            String pagamento = pegarPagamentoEscolhido();
            Intent intentResultado = new Intent(this, ResultadoPizzaActivity.class);
            intentResultado.putExtra("tamanho", tamanhoPreco[0]);
            intentResultado.putExtra("preco", tamanhoPreco[1]);
            intentResultado.putExtra("sabores", intentSabores.getStringExtra("sabores"));
            intentResultado.putExtra("pagamento", pagamento);
            startActivity(intentResultado);
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void inicializarComponentes(){
        rgPizzaTamanho = findViewById(R.id.rgPizzaTamanho);
        rgPagamento = findViewById(R.id.rgPagamento);
        rbBroto = findViewById(R.id.rbBroto);
        rbMedia = findViewById(R.id.rbMedia);
        rbGrande = findViewById(R.id.rbGrande);
        rbExtraGrande = findViewById(R.id.rbExtraGrande);
        btnConfirmar = findViewById(R.id.btnConfirmar);

    }

    private String[] pegarTamanhoEscolhido(){
        String[] tamanhoPreco = new String[2];
        RadioButton selecionado = findViewById(rgPizzaTamanho.getCheckedRadioButtonId());
        if (selecionado == rbBroto){
            tamanhoPreco[0] = "Broto";
            tamanhoPreco[1] = "R$ 12,00";
        }
        else if (selecionado == rbMedia){
            tamanhoPreco[0] = "Média";
            tamanhoPreco[1] = "R$ 18,00";
        }
        else if (selecionado == rbGrande){
            tamanhoPreco[0] = "Grande";
            tamanhoPreco[1] = "R$ 24,00";
        }
        else if (selecionado == rbExtraGrande){
            tamanhoPreco[0] = "Extra Grande";
            tamanhoPreco[1] = "R$ 35,00";

        } else {
            tamanhoPreco[0] = "";
            tamanhoPreco[1] = "";
        }
        return tamanhoPreco;
    }

    private String pegarPagamentoEscolhido(){
        RadioButton selecionado = findViewById(rgPagamento.getCheckedRadioButtonId());
        return selecionado.getText().toString();
    }
}