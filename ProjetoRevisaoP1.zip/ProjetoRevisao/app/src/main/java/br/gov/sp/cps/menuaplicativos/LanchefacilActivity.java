package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LanchefacilActivity extends AppCompatActivity {
    private Button btnPedido, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.lanchefacil);
        btnPedido = findViewById(R.id.btnPedido);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnPedido.setOnClickListener(view -> {
            Intent intent = new Intent(this, FormularioPedidoActivity.class);
            startActivity(intent);
            finish();
        });
        btnVoltar.setOnClickListener(view -> {
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}