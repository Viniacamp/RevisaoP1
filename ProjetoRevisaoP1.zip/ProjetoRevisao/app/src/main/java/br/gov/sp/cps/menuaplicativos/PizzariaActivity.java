package br.gov.sp.cps.menuaplicativos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PizzariaActivity extends AppCompatActivity {
    private CheckBox ckMussarela, ckPortuguesa, ckCalabresa, ckMarguerita, ckFrangoCatupiry, ckQuatroQueijos, ckPepperoni;
    private Button btnProximo, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.pizzaria);
        inicializarComponentes();
        btnProximo.setOnClickListener(view -> {
            String sabores = listarSabores();
            if (sabores.equals("")){
                Toast.makeText(this, "Selecione pelo menos um sabor", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, SelecaoPizzaActivity.class);
            intent.putExtra("sabores", sabores);
            startActivity(intent);
            finish();
        });

        btnVoltar.setOnClickListener(view -> {
            finish();
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void inicializarComponentes(){
        ckMussarela = findViewById(R.id.ckMussarela);
        ckPortuguesa = findViewById(R.id.ckPortuguesa);
        ckCalabresa = findViewById(R.id.ckCalabresa);
        ckMarguerita = findViewById(R.id.ckMarguerita);
        ckFrangoCatupiry = findViewById(R.id.ckFrangoCatupiry);
        ckQuatroQueijos = findViewById(R.id.ckQuatroQueijos);
        ckPepperoni = findViewById(R.id.ckPepperoni);
        btnProximo = findViewById(R.id.btnProximo);
        btnVoltar = findViewById(R.id.btnVoltar);
    }

    private String listarSabores(){
        String sabores = "";
        int qtdeSabores = 0;

        if (ckMussarela.isChecked()){
            sabores += " Mussarela,";
            qtdeSabores++;
        }
        if (ckPortuguesa.isChecked()){
            sabores += " Portuguesa,";
            qtdeSabores++;
        }
        if (ckCalabresa.isChecked()){
            sabores += " Calabresa,";
            qtdeSabores++;
        }
        if (ckMarguerita.isChecked()) {
            sabores += " Marguerita,";
            qtdeSabores++;
        }
        if (ckFrangoCatupiry.isChecked()){
            sabores += " Frango com Catupiry,";
            qtdeSabores++;
        }
        if (ckQuatroQueijos.isChecked()) {
            sabores += " Quatro Queijos,";
            qtdeSabores++;
        }

        if (ckPepperoni.isChecked()){
            sabores+= " Pepperoni,";
            qtdeSabores++;
        }
        if (qtdeSabores == 0){
            return "";
        }

        sabores = sabores.substring(0, sabores.length() - 1) + ".";
        return sabores;




    }
}